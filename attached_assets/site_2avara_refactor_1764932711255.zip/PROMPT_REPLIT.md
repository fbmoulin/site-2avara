# Prompt para o Replit (Ghostwriter / Assistente de IA)

Você está atuando em um projeto React + Vite + TypeScript que implementa
o site institucional da 2ª Vara Cível de Cariacica/ES.

Objetivo: aplicar uma refatoração de front-end para:
- organizar o código em rotas (páginas) usando react-router-dom;
- criar um layout padrão com Navbar e Footer persistentes;
- adicionar transições suaves (fade-in/fade-out) entre páginas usando framer-motion;
- preparar o projeto para futuras integrações (chatbot, agendamento, notícias dinâmicas).

Tarefas que você deve executar neste projeto:

1. Instale as dependências de roteamento e animação:
   - react-router-dom
   - framer-motion

   Comando sugerido:
   npm install react-router-dom framer-motion

2. Garanta que o arquivo src/main.tsx envolva o componente <App /> em <BrowserRouter>,
   conforme o seguinte modelo (ajuste apenas se necessário, sem quebrar o restante do projeto):

   - Utilize o conteúdo de src/main.tsx incluído neste ZIP como referência principal.

3. Substitua o conteúdo atual de:
   - src/App.tsx
   - src/routes/Router.tsx (crie se ainda não existir)
   - src/components/layout/Layout.tsx
   - src/components/layout/Navbar.tsx
   - src/components/layout/Footer.tsx
   - src/pages/Home/HomePage.tsx
   - src/pages/Agendamento/AgendamentoPage.tsx
   - src/pages/Noticias/NoticiasPage.tsx
   - src/pages/Contato/ContatoPage.tsx
   - src/pages/Admin/AdminPage.tsx

   pelos arquivos fornecidos neste ZIP.

4. Ajuste, se necessário, importações e caminhos relativos, respeitando a estrutura
   existente do projeto (por exemplo, se já houver uma pasta src/components, reutilize-a).

5. Compile o projeto (npm run dev / npm run build) e corrija qualquer erro de TypeScript
   ou importação, mantendo a lógica fornecida.

6. Não remova integrações de backend (Express, Prisma, PostgreSQL) já existentes.
   Apenas ajuste o front-end para utilizar as novas rotas e layout.

7. Após a aplicação das mudanças, verifique:
   - Navegação entre as rotas: "/", "/agendamento", "/noticias", "/contato" e "/admin".
   - Funcionamento das transições animadas entre páginas.
   - Presença da Navbar e do Footer em todas as páginas.
   - Ausência de erros no console do navegador e no terminal.

Seu foco é garantir que o projeto passe a ter:
- Estrutura de páginas clara;
- Layout consistente;
- Transições suaves (UX moderna);
- Compatibilidade com o restante do código já existente no repositório.
