import React from "react";
import { Routes, Route } from "react-router-dom";
import HomePage from "../pages/Home/HomePage";
import AgendamentoPage from "../pages/Agendamento/AgendamentoPage";
import NoticiasPage from "../pages/Noticias/NoticiasPage";
import ContatoPage from "../pages/Contato/ContatoPage";
import AdminPage from "../pages/Admin/AdminPage";

const AppRouter: React.FC = () => {
  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/agendamento" element={<AgendamentoPage />} />
      <Route path="/noticias" element={<NoticiasPage />} />
      <Route path="/contato" element={<ContatoPage />} />
      <Route path="/admin" element={<AdminPage />} />
    </Routes>
  );
};

export default AppRouter;
