import React from "react";

const ContatoPage: React.FC = () => {
  return (
    <section>
      <h2>Localização e Contato</h2>
      <p>
        Endereço do Fórum, telefones de contato, e-mail institucional e 
        outras formas de atendimento.
      </p>

      <div style={{ marginTop: "1.5rem" }}>
        {/* Substitua o src abaixo pelo embed oficial do Google Maps do Fórum */}
        <iframe
          title="Mapa Fórum de Cariacica"
          src="https://www.google.com/maps/embed?pb="
          width="100%"
          height="350"
          style={{ border: 0 }}
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
        ></iframe>
      </div>
    </section>
  );
};

export default ContatoPage;
