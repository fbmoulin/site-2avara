import React from "react";
import { Link } from "react-router-dom";

const HomePage: React.FC = () => {
  return (
    <section>
      <h1>2ª Vara Cível de Cariacica/ES</h1>
      <p>
        Bem-vindo ao site institucional da 2ª Vara Cível de Cariacica. 
        Aqui você encontra informações sobre atendimentos, regras de demandas,
        agendamentos, notícias e orientações aos jurisdicionados e advogados.
      </p>

      <div className="home-cards">
        <Link to="/agendamento" className="card">
          <h3>Agendamentos e Chatbot</h3>
          <p>Solicite atendimento ou tire dúvidas com o apoio do chatbot.</p>
        </Link>
        <Link to="/noticias" className="card">
          <h3>Notícias e Comunicados</h3>
          <p>Acompanhe avisos e comunicados importantes da Vara.</p>
        </Link>
        <Link to="/contato" className="card">
          <h3>Localização e Contato</h3>
          <p>Veja como chegar ao Fórum e canais oficiais de contato.</p>
        </Link>
      </div>
    </section>
  );
};

export default HomePage;
