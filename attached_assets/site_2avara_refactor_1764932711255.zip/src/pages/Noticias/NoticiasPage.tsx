import React from "react";

const NoticiasPage: React.FC = () => {
  return (
    <section>
      <h2>Notícias e Comunicados</h2>
      <p>
        Publicações, comunicados, avisos e informações relevantes sobre a 
        2ª Vara Cível de Cariacica.
      </p>

      <div style={{ marginTop: "1.5rem" }}>
        {/* 
          Aqui você poderá consumir a API /api/articles do seu backend
          e listar as notícias em formato de cards.
        */}
        <p>
          Em breve, esta seção exibirá automaticamente as notícias cadastradas no sistema.
        </p>
      </div>
    </section>
  );
};

export default NoticiasPage;
