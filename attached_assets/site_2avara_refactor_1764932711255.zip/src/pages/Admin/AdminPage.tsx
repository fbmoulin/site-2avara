import React from "react";

const AdminPage: React.FC = () => {
  return (
    <section>
      <h2>Painel Administrativo</h2>
      <p>
        Área reservada à equipe da Vara para gestão de notícias, comunicados
        e demais conteúdos dinâmicos do site.
      </p>
    </section>
  );
};

export default AdminPage;
