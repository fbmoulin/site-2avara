import React from "react";

const AgendamentoPage: React.FC = () => {
  return (
    <section>
      <h2>Agendamentos e Chatbot</h2>
      <p>
        Utilize esta seção para solicitar agendamento de atendimento com a Vara
        e obter informações iniciais por meio do chatbot.
      </p>

      <div style={{ marginTop: "1.5rem" }}>
        {/* Aqui, no futuro, você pode integrar:
            - formulário de agendamento
            - componente de chatbot (iframe ou componente que consome sua API de IA)
        */}
        <p>
          Em breve, esta página contará com um formulário estruturado de agendamento
          e um chatbot integrado às rotinas da Vara.
        </p>
      </div>
    </section>
  );
};

export default AgendamentoPage;
