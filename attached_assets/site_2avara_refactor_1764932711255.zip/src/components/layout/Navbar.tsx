import React from "react";
import { Link, useLocation } from "react-router-dom";

const Navbar: React.FC = () => {
  const location = useLocation();

  const isActive = (path: string) =>
    location.pathname === path ? "nav-link active" : "nav-link";

  return (
    <header className="navbar">
      <div className="navbar__brand">
        <span className="navbar__brand-top">Poder Judiciário do Estado do Espírito Santo</span>
        <strong className="navbar__brand-main">2ª Vara Cível de Cariacica</strong>
      </div>

      <nav className="navbar__links">
        <Link className={isActive("/")} to="/">Início</Link>
        <Link className={isActive("/agendamento")} to="/agendamento">Agendamentos / Chatbot</Link>
        <Link className={isActive("/noticias")} to="/noticias">Notícias</Link>
        <Link className={isActive("/contato")} to="/contato">Localização / Contato</Link>
        {/* <Link className={isActive("/admin")} to="/admin">Admin</Link> */}
      </nav>
    </header>
  );
};

export default Navbar;
