import React from "react";

const Footer: React.FC = () => {
  return (
    <footer className="footer">
      <p>
        2ª Vara Cível de Cariacica/ES – Poder Judiciário do Estado do Espírito Santo
      </p>
      <p>
        Este site possui caráter informativo e não substitui as publicações oficiais.
      </p>
    </footer>
  );
};

export default Footer;
